#include<stdio.h>
#include<string.h>
#define MAX 100
int count=0;
char T[MAX],P[MAX];
int last(char c,int i)
{
    int j;
	for(j=i-1;j>=0;j--)
	{count++;
        if (c == T[j])
		{ 
            count++;
            return j;           
        }count++;
    }
    count++;
    return MAX;
}
int min(int x,int y)
{
    count++;
	return x < y ? x : y;
}
int BMMatch(char T[],char P[])
{
    int i,n,m,j;
	n=strlen(T);count++;
	m=strlen(P);count++;
    i = m-1;
	j = m-1; 
    do
	{
        if (P[j] == T[i])
		{
			if (j == 0)
			{count++;
                count++;
                return i;           
            }
            else
            {
				i--;count++;
                j--;count++;
            }
        }
        else
		{
			i=i+m-min(j,1+last(T[i],i));count+=3;
            j=m-1;count++;
        }count++;
    }while(i<n-1);
    count++;
    return -1;
}
int main()
{
	int pos;
	printf("Enter the string T : ");count++;
	gets(T);count++;
	printf("Enter the string P : ");count++;
	gets(P);count++;
	pos=BMMatch(T,P);count++;
	if(pos==-1)
	{
		printf("\nThere is no substring of T matching P\n");count++;
	}
	else
	{
		printf("\nSubstring P found at index %d in string P\n",pos);count++;
	}count++;
	printf("\nStep Count is %d\n",count);
	return 0;
}
