#include<stdio.h>
#define MAX 100
int count=0;
int arr[MAX];
int partition(int arr[],int low,int high)
{
	int pivot=arr[low];
	int i=low,j=high;
	while(i<=j)
	{
		count++;
		while(arr[i]>=pivot)
		{
			count++;
			i++;count++;
		}count++;
		while(arr[j]<=pivot)
		{
			count++;
			j--;count++;
		}count++;
		if(i<j)
		{
			swap(arr,i,j);count++;
		}count++;
	}count++;
	arr[low]=arr[j];count++;
	arr[j]=pivot;count++;
	count++;
	return j;
}
void quicksort(int arr[],int low,int high)
{
	int j;
	if(low<high)
	{
		j=partition(arr,low,high);count++;
		quicksort(arr,low,j-1);count++;
		quicksort(arr,j+1,high);count++;
	}
	count++;
}
void swap(int arr[],int i,int j)
{
	int tmp=arr[i];count++;
	arr[i]=arr[j];count++;
	arr[j]=tmp;count++;
}
int main()
{
    int arr[MAX],n,x,i;
    printf("Enter the size of the array : ");count++;
    scanf("%d",&n);count++;
    printf("Enter the elements : ");count++;
    count++;
    for(i=1;i<=n;i++)
    {
        count++;
        scanf("%d",&arr[i]);
    }count++;
    
    quicksort(arr,1,n);
    
    printf("\nSorted array : ");count++;
    for(i=1;i<=n;i++)
    {
    	count++;
		printf("%d ",arr[i]);
	}count++;
    
    printf("\n\nStep Count is %d\n",count);
    return 0;
}
