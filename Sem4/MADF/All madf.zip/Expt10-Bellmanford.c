#include <stdio.h>
#include<stdlib.h>
#define MAX 100
#define infinity 999999
int count=0;
int cost[MAX][MAX];
int path[MAX][MAX];
int dist[MAX];
int n;
void create_graph();
void display();
void bellmanford(int v);

int main()
{
	int v,i;
	create_graph();count++;
	printf("\n\nEnter the souce vertex : ");
	scanf("%d",&v);
	bellmanford(v);
	printf("\nThe shortest distance to go from : ");
    for(i=1;i<=n;i++)
    {
    	count++;
		printf("\n%d to %d : ",v,i);count++;
		if(dist[i]>=infinity)
		printf("No path");
		else
		printf("%d",dist[i]);
		count+=2;
	}count++;
	printf("\n");
	printf("\nStep Count is %d\n",count);
    return 0;
}
void bellmanford(int v)
{
	int i,u,k;
	for(i=1;i<=n;i++)
	{
		count++;
		dist[i]=cost[v][i];count++;
	}
	for(k=2;k<=n-1;k++)
	{count++;
		for(u=1;u<=n;u++)
		{count++;
			for(i=1;i<=n;i++)
			{count++;
				if(u!=v && cost[i][u]!=infinity)
				{
					if(dist[u]>dist[i]+cost[i][u])
					{
						dist[u]=dist[i]+cost[i][u];count++;
					}count++;
				}count+=2;
			}count++;
		}count++;
	}count++;
}
void create_graph()
{
   	int i,max_edges,destin,origin,ct,j;
   	printf("Enter the number of vertices : ");
   	scanf("%d",&n);count++;
    max_edges=n*(n-1);count++;
    printf("\nEnter the edges : ");

    for(i=1;i<=max_edges;i++)
    {
        count++;
        printf("\nEdge %d(-1,-1) to quit : ",i);
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
            count+=2;
            break;
		}count++;
        if(origin>n || destin>n || origin<1 || destin<1)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            printf("Cost to go from %d to %d  : ",origin,destin);count++;
            scanf("%d",&ct);count++;
            cost[origin][destin]=ct;count++;
        }count++;
    }count++;
    printf("\nAdjacency Matrix :\n");count++;
	display(cost);count++;
    for(i=1;i<=n;i++)
	{
		count++;
		for(j=1;j<=n;j++)
		{
			count++;
			if (cost[i][j] == 0 && i!=j)
			{
				cost[i][j] = infinity;count++;
			}count+=2;
		}count++;
	}count++;
}
void display(int mat[MAX][MAX])
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			count++;
			printf("%5d",mat[i][j]);
		}
		printf("\n");
	}
}
