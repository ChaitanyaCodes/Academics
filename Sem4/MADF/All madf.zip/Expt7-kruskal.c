#include <stdio.h>
#include<stdlib.h>
#define MAX 100
int count=0;
int adj[MAX][MAX];
int spanning[MAX][MAX];
int n;
void create_graph();
void display();
void kruskal();
int find(int belongs[], int vertexno);
void union1(int belongs[], int c1, int c2);
void sort();
typedef struct edge
{
    int u, v, w;
} edge;

typedef struct edgelist
{
    edge data[MAX];
    int n;
} edgelist;
edgelist spanlist;
edgelist elist;
int main()
{
    int choice,origin,destin;
    int wt_tree=0,i,root,j,cost;
    create_graph();count++;
    printf("\nAdjacency matrix : \n");
    display();count++;
    cost = 0;count++;
    kruskal();count++;
    printf("\n Edge\t Weight\n");
    for (i = 0; i < spanlist.n; i++)
    {
        count++;
		printf("%d -- %d\t   %d\n", spanlist.data[i].u, spanlist.data[i].v, spanlist.data[i].w);count++;
        cost = cost + spanlist.data[i].w;count++;
    }
	printf("\nCost of spanning tree is : %d\n",cost);count++;
	printf("\nStep Count is %d\n",count);
    return 0;
}
void create_graph()
{
    int i,max_edges,destin,origin,wt;
    printf("Enter the number of vertices : ");
    scanf("%d",&n);count++;
    max_edges=n*(n-1);count++;
    printf("\nEnter the edges and weights");

    for(i=1;i<=max_edges;i++)
    {
        count++;
		printf("\nEdge %d(-1,-1) to quit : ",i);count++;
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
        	count+=3;
			break;
		}count++;
        printf("Weight : ");
        scanf("%d",&wt);count++;
        if(origin>=n || destin>=n || origin<0 || destin<0)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            adj[origin][destin]=wt;count++;
            adj[destin][origin]=wt;count++;
        }
        count++;
    }count++;
}
void display()
{
    int i,j;
    for(i=0;i<n;i++)
    {
		count++;
		for(j=0;j<n;j++)
        {
        	count++;
			printf("%4d",adj[i][j]);count++;
		}count++;
        printf("\n");
    }count++;
}
void kruskal()
{
    int belongs[MAX], i, j, cno1, cno2;
    elist.n = 0;count++;

    for (i = 1; i < n; i++)
    {
    	count++;
		for (j = 0; j < i; j++)
        {
            count++;
			if (adj[i][j] != 0)
            {
                elist.data[elist.n].u = i;count++;
                elist.data[elist.n].v = j;count++;
                elist.data[elist.n].w = adj[i][j];count++;
                elist.n++;count++;
            }count++;
        }count++;
	}count++;
    sort();count++;
    for (i = 0; i < n; i++)
    {
    	count++;
		belongs[i] = i;count++;
	}count++;
    spanlist.n = 0;count++;
    for (i = 0; i < elist.n; i++)
    {
        count++;
		cno1 = find(belongs, elist.data[i].u);count++;
        cno2 = find(belongs, elist.data[i].v);count++;
        if (cno1 != cno2)
        {
            spanlist.data[spanlist.n] = elist.data[i];count++;
            spanlist.n = spanlist.n + 1;count++;
            union1(belongs, cno1, cno2);count++;
        }count++;
    }
}

int find(int belongs[], int vertexno)
{
    count++;
	return (belongs[vertexno]);
}

void union1(int belongs[], int c1, int c2)
{
    int i;
    for (i = 0; i < n; i++)
    {
    	count++;
		if (belongs[i] == c2)
        {
        	belongs[i] = c1;count++;
		}count++;
	}count++;
}
void sort()
{
    int i, j;
    edge temp;
    for (i = 1; i < elist.n; i++)
    {
    	count++;
		for (j = 0; j < elist.n - 1; j++)
        {
        	count++;
			if (elist.data[j].w > elist.data[j + 1].w)
            {
                temp = elist.data[j];count++;
                elist.data[j] = elist.data[j + 1];count++;
                elist.data[j + 1] = temp;count++;
            }count++;
		}count++;
	}count++;
}


