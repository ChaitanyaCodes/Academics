#include<stdio.h>
#include<stdlib.h>
#define MAX 100
int count=0,c=0;
int m,w[MAX];
int x[MAX];
void write(int x[],int k)
{
	int i;
	printf(" (");
	for(i=1;i<=k;i++)
	{count++;
		printf(" %d %c",x[i],(i==k)?')':',');count+=3;
	}count++;
	printf("\n");
}
void SumofSubsets(int s,int k,int r)
{
	x[k]=1;
	if(s+w[k]==m)
	{
		count++;
		write(x,k);count++;
		c++;count++;
	}
	else if(s+w[k]+w[k+1]<=m)
	{
		count++;
		SumofSubsets(s+w[k],k+1,r-w[k]);count++;
	}count++;
	
	if((s+r-w[k]>=m)&&(s+w[k+1]<=m))
	{
		count+=2;
		x[k]=0;count++;
		SumofSubsets(s,k+1,r-w[k]);count++;
	}count+=2;
}

int main()
{
	int i,n,sum=0;count++;
	printf("Enter the number of weight entries : ");
	scanf("%d",&n);count++;
	printf("Enter the value of m : ");
	scanf("%d",&m);count++;
	printf("\nEnter the value of \n");
	for(i=1;i<=n;i++)
	{count++;
		printf("Weight %d : ",i);count++;
		scanf("%d",&w[i]);count++;
		sum+=w[i];count++;
		x[i]=0;count++;
	}
	printf("\nW = {");
	for(i=1;i<=n;i++)
	{count++;
		printf(" %d %c",w[i],(i==n)?'}':',');count+=3;
	}count++;
	printf("\n\nThe solutions of sum of subset problems are :\n");
	SumofSubsets(0,1,sum);count++;
	printf("\nStep Count is %d\n",count);
	return 0;
}
