#include<stdio.h>
#include<stdlib.h>
#define MAX 20
int count=0;
int m,n;
float maxprof;
float minwght;
float pibyxi;
struct node
{
    float profit;
    float weight;
    float sol;
};
struct node item[MAX];
void swap(struct node **t1,struct node **t2)
{
	struct node *temp;
	temp=*t1;count++;
	*t1=*t2;count++;
	*t2=temp;count++;
}
void copy(struct node xitem[],int n,struct node *x[])
{
    int i;
    for(i=0;i<n;i++)
    {
        count++;
		x[i]=&xitem[i];count++;
    }count++;
}
void calprofit(float *pixi)
{
	int i;
	count++;
	*pixi=0;
	printf("\nChoices of Objects : (");
    for(i=0;i<n;i++)
    {
        count++;
		*pixi+=item[i].profit*item[i].sol;count++;
        printf("%.2f%c",item[i].sol,(i==n-1)?')':',');count+=2;
    }count++;
    printf("\nProfit = %.2f\n",*pixi);count++;
}
void knapsack(struct node *x[])
{
    int i;
    for(i=0;i<n;i++)
    {
        count++;
		x[i]->sol=0;count++;
    }count++;
    int u=m;count++;
    for(i=0;i<n;i++)
    {
        count+=2;
		if(x[i]->weight<u)
        {
			u=u-x[i]->weight;count++;
            x[i]->sol=1;count++;
        }
        else break;
    }
    if(i!=n)
    { 
		x[i]->sol=u/(x[i]->weight);count++;
    }count++;
}
void maxprofit()
{
    int i,j;
    struct node *temp[MAX];
    copy(item,n,temp);count++;

    for(i=0;i<n-1;i++)
    {
        count++;
		for(j=0;j<n-1-i;j++)
        {
            count++;
			if(temp[j]->profit<temp[j+1]->profit)
            {
				swap(&temp[j],&temp[j+1]);count++;
            }count++;
        }count++;
    }count++;
    knapsack(temp);count++;
}
void minweight()
{
    int i,j;
    struct node *temp[MAX];
    copy(item,n,temp);count++;

    for(i=0;i<n-1;i++)
    {
        count++;
		for(j=0;j<n-1-i;j++)
        {
            count++;
			if(temp[j]->weight>temp[j+1]->weight)
            {
				swap(&temp[j],&temp[j+1]);count++;
            }count++;
        }count++;
    }count++;
    knapsack(temp);count++;
}
void decrepiwi()
{
    int i,j;
    struct node *temp[MAX];
    copy(item,n,temp);count++;

    for(i=0;i<n-1;i++)
    {
        count++;
		for(j=0;j<n-1-i;j++)
        {
			count++;
			if((temp[j]->profit/temp[j]->weight)<(temp[j+1]->profit/temp[j+1]->weight))
            {
               swap(&temp[j],&temp[j+1]);count++;
            }count+=3;
        }count++;
    }count++;
    knapsack(temp);count++;
}
int main()
{
	int choice,i,a;
	float *p;
	printf("Enter the number of objects : ");
	scanf("%d",&n);count++;
	printf("Enter the capacity of the bag : ");
	scanf("%d",&m);count++;
	printf("\nEnter the weight and profit of : \n");
	for(i=0;i<n;i++)
	{
		count++;
		printf("Object %d : ",i+1);count++;
		scanf("%f %f",&item[i].weight,&item[i].profit);count++;
	}count++;
	printf("\nProfits : (");
	for(i=0;i<n;i++)
	{
		count++;
		printf("%.2f%c",item[i].profit,(i==n-1)?')':',');count+=2;
	}count++;
	printf("\nWeights : (");
	for(i=0;i<n;i++)
	{
		count++;
		printf("%.2f%c",item[i].weight,(i==n-1)?')':',');count++;
	}count++;printf("\n");
	while(1)
	{
		count++;
		printf("\n===================================\n");
		printf("1. to show for max profit\n");
		printf("2. to show for min weight\n");
		printf("3. to show for decreasing profit\n");
		printf("4. to Exit\n");
		printf("\nEnter the choice : ");
		scanf("%d",&choice);count++;
		switch(choice)
		{
			case 1:
                maxprofit();count++;
                calprofit(&maxprof);count++;
				break;
			case 2:
                minweight();count++;
                calprofit(&minwght);count++;
				break;
			case 3:
                decrepiwi();count++;
                calprofit(&pibyxi);count++;
				break;
			case 4:
				if(maxprof>minwght)
				{
					p=&maxprof;
					a=1;
					if(pibyxi>maxprof)
					{
						p=&pibyxi;
						a=3;
					}
				}
				else
				{
					p=&minwght;
					a=1;
					if(pibyxi>minwght)
					{
						p=&pibyxi;
						a=3;
					}
				}
				printf("\nOptimal solution  is %.2f,\nand is obtained by taking",*p);
				count++;
				if(a==1)
				{
					count++;
					printf(" maximum price of objects\n");
				}
				else if(a==2)
				{
					count+=2;
					printf(" least weight of objects\n");
				}
				else if(a==3)
				{
					count+=3;
					printf(" decreasing order of Pi/Wi of objects\n");
				}
				printf("\nStep Count is %d\n",count);
				exit(1);
			default:
				printf("\n\nInvalid choice!!!\n");count++;
		}
	}
}
