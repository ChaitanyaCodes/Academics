#include<stdio.h>
int count=0;
int main()
{
	int A[2][2], B[2][2], C[2][2],i,j;
	int P,Q,R,S,T,U,V;
	
	printf("Enter matrix A :\n");count++;
	for(i=0;i<2;i++)
	{
		count++;
		for(j=0;j<2;j++)
		{
			count++;
			scanf("%d",&A[i][j]);count++;
		}count++;
	}count++;

	printf("Enter matrix B :\n");count++;
	for(i=0;i<2;i++)
	{
		count++;
		for(j=0;j<2;j++)
		{
			count++;
			scanf("%d",&B[i][j]);count++;
		}count++;
	}count++;

	printf("\nMatrix A : \n");count++;
	for(i=0;i<2;i++)
	{
		count++;
		for(j=0;j<2;j++)
		{
			count++;
			printf("%-4d",A[i][j]);count++;
		}count++;
		printf("\n");
	}count++;

	printf("\n\nMatrix B :\n");count++;
	for(i=0;i<2;i++)
	{
		count++;
		for(j=0;j<2;j++)
		{
			count++;
			printf("%-4d",B[i][j]);count++;
		}count++;
		printf("\n");
	}count++;

	P = (A[0][0]+A[1][1])*(B[0][0]+B[1][1]);count++;
	Q = (A[1][0]+A[1][1])*B[0][0];count++;
	R = A[0][0]*(B[0][1]-B[1][1]);count++;
	S = A[1][1]*(B[1][0]-B[0][0]);count++;
	T = (A[0][0]+A[0][1])*B[1][1];count++;
	U = (A[1][0]-A[0][0])*(B[0][0]+B[0][1]);count++;
	V = (A[0][1]-A[1][1])*(B[1][0]+B[1][1]);count++;

	C[0][0]= P+S-T+V;count++;
	C[0][1]= R+T;count++;
	C[1][0]= Q+S;count++;
	C[1][1]= P+R-Q+U;count++;

	printf("\n\nMatrix C = A * B : \n");count++;
	for(i=0;i<2;i++)
	{
		count++;
		for(j=0;j<2;j++)
		{
			count++;
			printf("%-4d",C[i][j]);count++;
		}count++;
		printf("\n");
	}count++;

	printf("\n\nStep count is %d\n",count);
	return 0;
}
