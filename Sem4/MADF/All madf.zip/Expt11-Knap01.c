#include<stdio.h>
#include<stdlib.h>
#define MAX 20
int count=0; 
typedef struct 
{ 
    int p; 
    int w;
}PW; 
int search(int L,int H,int pp,int ww,PW pair[]) 
{ 
    int low=L; 
    int high=H; 
    count+=2; 
    while(low<=high) 
    { 
        count++;
        int mid= (low+high)/2;count++; 
        if(pair[mid].p==pp&&pair[mid].w==ww) 
        { 
            count++; 
            return 1; 
        } 
        else if(pair[mid].w<ww) 
        { 
            count++;
            low=mid+1; 
            count++;
        } 
        else 
        { 
            high = mid-1; 
            count++; 
        } 
    } 
    count++; 
    count++; 
    return 0; 
} 
void Traceback(int p[],int w[],PW pair[],int x[],int m,int n,int b[]) 
{ 
	int last=b[n+1]-1,j,i; 
	int pp=pair[last].p; 
    int ww=pair[last].w; 
    int k=n; 
    count+=4; 
    while(pp>0 &&ww>0) 
    { 
	    count++;
	    int f=1; 
	    count++;
	    for(j=k;j>=0;j--) 
	    { 
	        count++;
	        f=search(b[j],b[j+1]-1,pp,ww,pair); 
	        count++;
	        count++;
	        if(!f) 
	        { 
		        count++; 
		        if(j!=n) 
		        { 
		        x[j+1] =1; 
		        pp=pp-p[j+1]; 
		        ww =ww-w[j+1]; 
		        count+=3;
	        	} 
	        	else 
	        	{ 
			        x[j] = 1; 
			        pp=pp-p[j]; 
			        ww =ww-w[j]; 
			        count+=3; 
		    	} 
				k=j; 
				count++; 
				count++;
				break; 
			} 
    	} 
    	count++;
    } 
    count++;
    printf("\nChoices of Objects : ("); 
    count++;
    for(i=1;i<=n;i++) 
    { 
	    count++;
	    printf("%d%c",x[i],(i==n)?')':',');count+=2;
    } 
    count++;
    printf("\n");
    count++;
} 
int largest(PW pair[],int w[],int t,int h,int i,int m) 
{ 
	int low=t; 
	int high=h; 
	count+=2;
	int ans; 
 	while(low<=high) 
	{ 
		count++;
		int mid=(low+high)/2; 
		count++;
	 	count++;
		if(pair[mid].w+w[i]<=m)
		{ 
			ans=mid; 
			low=mid+1; 
			count+=2;
		} 
		else 
		{ 
			high=mid-1; 
		 	count++;
		} 
	} 
	count++;
	count++; 
	return ans; 
} 
void Dknap(int p[],int w[],int x[],int n,int m)
{ 
	PW pair[100]; 
	int b[n+1],i,j; 
	//S0 
	b[0]=1; 
	pair[1].p=0.0; 
 	pair[1].w=0.0; 
	int t=1,h=1;//start and end of s0 
	count+=4;
	b[1]=2; 
	int next=2; 
	count+=2; 
	for(i=1;i<=n;i++) 
	{ 
		count++;
		//generate si 
		int k=t; 
		int u=largest(pair,w,t,h,i,m); 
		count+=2;
		for(j=t;j<=u;j++) 
		{ 
			count++;
			//generate Si-1 and merge 
			int pp=pair[j].p+p[i]; 
			int ww=pair[j].w+w[i]; 
		 	count+=2; 
			//(pp,ww) is next element in sI-1 
			while((k<=h)&&(pair[k].w<=ww)) 
			{ 
				count++;  
				pair[next].p=pair[k].p; 
				pair[next].w=pair[k].w; 
			 	next++; 
				k++; 
				count+=4;
			} 
			count++; 
			count++;
			if((k<=h) && (pair[k].w==ww)) 
			{ 
				count++;
				if(pp<pair[k].p) 
				{ 
					pp=pair[k].p; 
				 	count++;
				} 
				k++; 
				count++;
			} 
			count++;
			if(pp>pair[next-1].p) 
			{ 
			 	pair[next].p=pp; 
				pair[next].w=ww; 
				next++; 
				count+=3;
			} 
			while((k<=h) && (pair[next].p<=pair[next-1].p)) 
			{ 
				count++;
				k++; 
				count++;
			} 
			count++;
		} 
		count++;
		//merge remaining terms 
		while(k<=h) 
		{ 
			count++;
			pair[next].p=pair[k].p; 
			pair[next].w=pair[k].w; 
			next++; 
			k++; 
			count+=4;
	 	} 
		count++; 
		//initialise S i+1 
		t=h+1; 
		h=next-1; 
		b[i+1]=next; 
		count+=3;
	} 
	count++;
 	printf("\nSubsets : \n");
	count++; 
	for(i=0;i<=n;i++) 
	{ 
		count++;
		printf("S%d = ",i);count++;
		for(j=b[i];j<=b[i+1]-1;j++) 
		{ 
			count++;
			printf(" ( %d , %d ) ",pair[j].p,pair[j].w);
			count++; 
		} 
		count++;
		printf("\n");
		count++;
	} 
	count++;
	Traceback(p,w,pair,x,m,n,b); 
} 
int main() 
{ 
 	int n,m,i; 
  	printf("Enter the number of objects : ");
	scanf("%d",&n);count++;
	printf("Enter the capacity of the bag : ");
	scanf("%d",&m);count++;
	printf("\nEnter the weight and profit of : \n"); 
	int p[MAX],w[MAX]; 
	for(i=1;i<=n;i++)
	{
		count++;
		printf("Object %d : ",i);count++;
		scanf("%d %d",&w[i],&p[i]);count++;
	}count++;
	count++;
	printf("\nProfits : (");
	for(i=1;i<=n;i++)
	{
		count++;
		printf("%d%c",p[i],(i==n)?')':',');count+=2;
	}count++;
	printf("\nWeights : (");
	for(i=1;i<=n;i++)
	{
		count++;
		printf("%d%c",w[i],(i==n)?')':',');count+=2;
	}count++;printf("\n");
	int x[n+1]; 
	for(i=0;i<=n+1;i++) 
	{ 
		count++; 
		x[i]=0; 
		count++; 
	} 
	count++;
	Dknap(p,w,x,n,m); 
	int profit=0,weight=0; 
	for(i=1;i<=n;i++) 
	{ 
		count++;
		profit+=(x[i]*p[i]); 
		weight+=(x[i]*w[i]);
		count+=2; 
	} 
	count++;
	printf("\nMaximum Profit : %d\n",profit);
	printf("Maximum weight : %d\n",weight);
	count+=2;
	count++;
	printf("\nStep Count is %d\n",count);
	return 0; 
}
