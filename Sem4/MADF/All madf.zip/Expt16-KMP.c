#include<stdio.h>
#include<string.h>
#define MAX 100
int count=0;
char T[MAX],P[MAX];
int f[MAX];
int n,m;
void failure(char *P,int f[])
{
	int i,j;
	i=1;count++;
	j=0;count++;
	f[0]=0;count++;
	while(i<m)
	{
		count++;
		if(P[j]==P[i])
		{
			count++;
			f[i]=j+1;count++;
			i=i+1;count++;
			j=j+1;count++;
		}
		else if(j>0)
		{
			count+=2;
			j=f[j-1];count++;
		}
		else
		{
			count+=2;
			f[i]=0;count++;
			i=i+1;count++;
		}
	}
}
int KMPMatch(char *T,char *P)
{
	int i,j;
	n=strlen(T);count++;
	m=strlen(P);count++;
	failure(P,f);count++;
	i=0;count++;
	j=0;count++;
	while(i<n)
	{
		count++;
		if(P[j]==T[i])
		{
			count++;
			if(j==m-1)
			{count++;
				count++;
				return i-m+1;
			}count++;
			i++;count++;
			j++;count++;
		}
		else if(j>0)
		{
			count+=2;
			j=f[j-1];count++;
		}
		else
		{count+=2;
			i++;count++;
		}
	}
	count++;
	return -1;
}
int main()
{
	char T[MAX],P[MAX];
	int pos;
	printf("Enter the string T : ");count++;
	gets(T);count++;
	printf("Enter the string P : ");count++;
	gets(P);count++;
	pos=KMPMatch(T,P);count++;
	if(pos==-1)
	{
		printf("\nThere is no substring of T matching P\n");count++;
	}
	else
	{
		printf("\nSubstring P found at index %d in string P\n",pos);count++;
	}count++;
	printf("\nStep Count is %d\n",count);
	return 0;
}
