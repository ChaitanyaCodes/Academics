#include<stdio.h>
#define MAX 100
int count=0;
 int arr[MAX];
void maxmin(int i,int j, int *max,int *min);
int main()
{
    int n,x,i,max,min;

    printf("Enter the size of the array : ");count++;
    scanf("%d",&n);count++;
    printf("Enter the elements : ");count++;
    for(i=1;i<=n;i++)
    {
    	count++;
    	scanf("%d",&arr[i]);
	}count++;
    
    maxmin(1,n,&max,&min);count++;
    printf("\nMax : %d\nMin : %d\n",max,min);count++;
    printf("\nStep Count is %d\n",count);
    return 0;
}
void maxmin(int i,int j,int *max,int *min)
{
    int max1,min1,mid;
	if(i==j)
    {
        count++;
		*max=*min=arr[i];count++;
    }
    else if(i==j-1)
    {
        count+=2;
		if(arr[i]<arr[j])
        {
            *max=arr[j];count++;
            *min=arr[i];count++;
        }
        else
        {
            *max=arr[i];count++;
            *min=arr[j];count++;
        }
        count++;
    }
    else
    {
        count+=2;
		mid=(i+j)/2;count++;
        maxmin(i,mid,max,min);count++;
        maxmin(mid+1,j,&max1,&min1);count++;
        if(*max<max1)
        {
			*max=max1;count++;
		}count++;
		if(*min>min1)
        {
			*min=min1;count++;
		}count++;
    }
}
