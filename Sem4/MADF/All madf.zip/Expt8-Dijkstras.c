#include <stdio.h>
#include<stdlib.h>
#define MAX 100
#define infinity 9999999
int count=0;
int cost[MAX][MAX];
int dist[MAX];
int S[MAX];
int n;
void create_graph();
void shortest_path();
int findmin();
void display(int mat[MAX][MAX]);
int main()
{
	int s;
	create_graph();count++;
	printf("\n\nEnter the source vertex : ");
	scanf("%d",&s);count++;
	shortest_path(s);count++;
	printf("\nStep Count is %d\n",count);
    return 0;
}
void shortest_path(int v)
{
	int i,u,w;
	for(i=1;i<=n;i++)
    {
        count++;
		S[i]=0;count++;
        dist[i]=cost[v][i];count++;
    }count++;
    S[v]=1;count++;
    dist[v]=0;count++;
    for(i=2;i<=n-1;i++)
    {
        count++;
		u=findmin();count++;
        S[u]=1;count++;
        
        for(w=1;w<=n;w++)
        {
        	count++;
        	if(cost[u][w]!=0 && S[w]==0)
        	{
				if(dist[w]>dist[u]+cost[u][w])
        		{
        			dist[w]=dist[u]+cost[u][w];count++;
				}count++;
			}count+=2;
		}count++;
    }count++;
    printf("\nThe shortest distance to go from : ");
    for(i=1;i<=n;i++)
    {
    	count++;
		printf("\n%d to %d : ",v,i);count++;
		if(dist[i]>=infinity)
		printf("No path");
		else
		printf("%d",dist[i]);
		count+=2;
	}count++;
	printf("\n");
}
int findmin()
{
    int k,i,min;
    min=infinity;count++;
    k=i;count++;
    for(i=1;i<=n;i++)
    {
    	count++;
        if(S[i]==0 && dist[i]<min)
        {
            k=i;count++;
            min=dist[i];count++;
        }count+=2;
    }count++;
    count++;
    return k;
}
void create_graph()
{
    int i,max_edges,destin,origin,ct,j;
    printf("Enter the number of vertices : ");
    scanf("%d",&n);count++;
    max_edges=n*(n-1);count++;
    printf("\nEnter the edges : ");

    for(i=1;i<=max_edges;i++)
    {
    	count++;
        printf("\nEdge %d(-1,-1) to quit : ",i);
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
        	count+=2;
        	break;
		}count++;
        if(origin>n || destin>n || origin<1 || destin<1)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            printf("Cost to go from %d to %d  : ",origin,destin);count++;
            scanf("%d",&ct);count++;
            cost[origin][destin]=ct;count++;
        }count++;
    }count++;
    printf("\nAdjacency Matrix :\n");count++;
	display(cost);count++;
    for(i=1;i<=n;i++)
	{
		count++;
		for(j=1;j<=n;j++)
		{
			count++;
			if (cost[i][j] == 0 && i!=j)
			{
				cost[i][j] = infinity;count++;
			}count+=2;
		}count++;
	}count++;
}
void display(int mat[MAX][MAX])
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			count++;
			printf("%5d",mat[i][j]);
		}
		printf("\n");
	}
}
