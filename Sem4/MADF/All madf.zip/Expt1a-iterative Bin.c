#include<stdio.h>
#define MAX 100
int count=0;
void sort(int arr[],int n);
int binary(int arr[],int n,int x);
int main()
{
    int arr[MAX],n,x,i;
    printf("Enter the size of the array : ");count++;
    scanf("%d",&n);count++;
    printf("Enter the elements : ");count++;
    count++;
    for(i=1;i<=n;i++)
    {
        count++;
        scanf("%d",&arr[i]);
    }count++;
    sort(arr,n);count++;
    printf("Sorted array : ");count++;
    
    for(i=1;i<=n;i++)
    {
    	count++;
		printf("%d ",arr[i]);
	}count++;
    
    printf("\nEnter the element to be searched : ");count++;
    scanf("%d",&x);count++;
    i=binary(arr,n,x);count++;
    if(i)
        printf("\n%d is found at position %d\n",x,i);
    else
        printf("\nThe element is not present in the array\n");
	count++;
    printf("\nStep Count is %d\n",count);
    return 0;
}
void sort(int arr[],int n)
{
	int i,j,tmp;
    for(i=1;i<n;i++)
    {
    	count++;
        for(j=1;j<=n-i;j++)
        {
            count++;
			if(arr[j]>arr[j+1])
            {
                tmp=arr[j];count++;
                arr[j]=arr[j+1];count++;
                arr[j+1]=tmp;count++;
            }
            count++;
        }count++;
    }count++;
}
int binary(int arr[],int n,int x)
{
    int low=1,high=n,mid;count+=2;
    while(low<=high)
    {
        count++;
		mid=(low+high)/2;count++;
        if(x<arr[mid])
        {
			count++;
			high=mid-1;count++;
		}
        else if(x>arr[mid])
        {
        	count+=2;
			low=mid+1;count++;
		}
        else
        {
        	count+=2;
			return mid;
		}
    }
    count++;
    return 0;
}
