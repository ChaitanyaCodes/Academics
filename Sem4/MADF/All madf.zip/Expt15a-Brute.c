#include<stdio.h>
#include<string.h>
#define MAX 100
char T[MAX],P[MAX];
int count=0;
int BruteForceMatch(char *T,char *P)
{
	int i,n,m,j;
	n=strlen(T);count++;
	m=strlen(P);count++;
	for(i=0;i<n-m;i++)
	{
		count++;
		j=0;count++;
		while(j<m && T[i+j]==P[j])
		{
			count+=2;
			j=j+1;count++;
		}count+=2;
		if(j==m)
		{count++;
			count++;
			return i;
		}count++;
	}count++;
	count++;
	return -1;
}
int main()
{
	int pos;
	printf("Enter the string T : ");count++;
	gets(T);count++;
	printf("Enter the string P : ");count++;
	gets(P);count++;
	pos=BruteForceMatch(T,P);count++;
	if(pos==-1)
	{
		printf("\nThere is no substring of T matching P\n");count++;
	}
	else
	{
		printf("\nSubstring P found at index %d in string P\n",pos);count++;
	}count++;
	printf("\nStep Count is %d\n",count);
	return 0;
}
