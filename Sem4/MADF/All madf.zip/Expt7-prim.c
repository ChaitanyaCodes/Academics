#include <stdio.h>
#include<stdlib.h>
#define MAX 100
#define infinity 9999999
int count=0;
int adj[MAX][MAX];
int spanning[MAX][MAX];
int n;
void create_graph();
void display();
int min_temp();
int main()
{
    int choice,origin,destin;
    int wt_tree=0,i,root,j;count++;
    create_graph();count++;
    printf("\nAdjacency matrix : \n");
    display();count++;
    wt_tree=prims();count+=2;
    printf("\n Edge\tweight\n");
    for(i=0;i<n;i++)
    {
        count++;
		for(j=0;j<n;j++)
        {
            count++;
			if(i>j && spanning[i][j])
            {
                count+=2;
				printf("%d -- %d\t  %d\n",i,j,spanning[i][j]);
            }count++;
        }count++;
    }count++;
	printf("\nCost of spanning tree is : %d\n",wt_tree);count++;
	printf("\nStep Count is %d\n",count);
    return 0;
}
void create_graph()
{
    int i,max_edges,destin,origin,wt;
    printf("Enter the number of vertices : ");
    scanf("%d",&n);count++;
    max_edges=n*(n-1);count++;
    printf("\nEnter the edges and weights");

    for(i=1;i<=max_edges;i++)
    {
        count++;
		printf("\nEdge %d(-1,-1) to quit : ",i);count++;
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
        	count+=3;
			break;
		}count++;
        printf("Weight : ");
        scanf("%d",&wt);count++;
        if(origin>=n || destin>=n || origin<0 || destin<0)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            adj[origin][destin]=wt;count++;
            adj[destin][origin]=wt;count++;
        }
        count++;
    }count++;
}
void display()
{
    int i,j;
    for(i=0;i<n;i++)
    {
		count++;
		for(j=0;j<n;j++)
        {
        	count++;
			printf("%4d",adj[i][j]);count++;
		}count++;
        printf("\n");
    }count++;
}
int prims()
{
    int cost[MAX][MAX];
    int u, v, min_distance, distance[MAX], from[MAX];
    int visited[MAX], no_of_edges, i, min_cost, j;
    for (i = 0; i < n; i++)
    {
    	count++;
		for (j = 0; j < n; j++)
        {
            count++;
			if (adj[i][j] == 0)
                cost[i][j] = infinity;
            else
                cost[i][j] = adj[i][j];
            count+=2;
            spanning[i][j] = 0;count++;
        }count++;
	}
    distance[0] = 0;count++;
    visited[0] = 1;count++;
    for (i = 1; i < n; i++)
    {
        count++;
		distance[i] = cost[0][i];count++;
        from[i] = 0;count++;
        visited[i] = 0;count++;
    }count++;
    min_cost = 0;count++;
    no_of_edges = n - 1;count++;
    while (no_of_edges > 0)
    {
        count++;
        min_distance = infinity;count++;
        for (i = 1; i < n; i++)
        {
        	count++;
			if (visited[i] == 0 && distance[i] < min_distance)
            {
                count+=2;
				v = i;count++;
                min_distance = distance[i];count++;
            }count++;
		}count++;
        u = from[v];count++;
        spanning[u][v] = distance[v];count++;
        spanning[v][u] = distance[v];count++;
        no_of_edges--;count++;
        visited[v] = 1;count++;
        for (i = 1; i < n; i++)
        {
        	count++;
			if (visited[i] == 0 && cost[i][v] < distance[i])
            {
				distance[i] = cost[i][v];count++;
                from[i] = v;count++;
            }count++;
		}
        min_cost = min_cost + cost[u][v];count++;
    }
    count++;
    return (min_cost);
}

