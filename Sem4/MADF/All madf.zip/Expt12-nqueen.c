#include <stdio.h>
#include<stdlib.h>
#include<math.h>
#define MAX 100
int x[MAX];
int solcnt=0;
int count=0;
int place(int k,int i)
{
	int j;
	for(j=1;j<=k-1;j++)
	{count++;
		if((x[j]==i)||(abs(x[j]-i)==abs(j-k)))
		{count+=2;
			return 0;
		}count++;
	}count++;
	count++;
	return 1;
}
void NQueens(int k,int n)
{
	int i,j;
	for(i=1;i<=n;i++)
	{count++;
		if(place(k,i))
		{
			x[k]=i;count++;
			if(k==n)
			{
				printf("( ");
				for(j=1;j<=n;j++)
				{count++;
					printf("%d %c ",x[j],(j==k)?')':',');count+=2;
				}count++;
				printf("\n");
				solcnt++;
			}
			else
			{
				count++;
				NQueens(k+1,n);
			}count++;
		}count++;
	}count++;

}
int main()
{
	int n;
	printf("Enter the value of n : ");count++;
	scanf("%d",&n);count++;
	printf("\n\nThe possible solution tuples are :\n");count++;
	NQueens(1,n);count++;
	printf("\nThe total number of possible solutions are : %d\n",solcnt);
	printf("\n\nThe step count is %d\n",count);
	return 0;
}

