#include <stdio.h>
#include<stdlib.h>
#define MAX 50
int count=0;
int G[MAX][MAX],x[MAX];
int n,m;
void create_graph();
void write(int x[],int n)
{
	int i;
	printf(" (");
	for(i=1;i<=n;i++)
	{count++;
		printf(" %d %c",x[i],(i==n)?')':',');count+=3;
	}count++;
	printf("\n");
}
void NextValue(int k)
{
	int j;
	do
	{
		count++;
		x[k]=(x[k]+1)%(m+1);count+=3;
		if(x[k]==0)
		{count++;
			count++;
			return;
		}
		for(j=1;j<=n;j++)
		{
			count++;
			if((G[k][j]!=0)&&(x[k])==x[j])
			{
				break;count+=2;
			}count+=2;
		}
		if(j==n+1)
		{count++;
			count++;
			return;
		}count++;
	}while(1);
}
void mColoring(int k)
{
	do
	{
		count++;
		NextValue(k);count++;
		if(x[k]==0)
		{count++;
			count++;
			return;
		}
		if(k==n)
		{
			count++;
			write(x,n);count++;
		}
		else 
		{
			count++;
			mColoring(k+1);count++;
		}
		
	}
	while(1);
	count++;
}
int main()
{
	int s;
	create_graph();count++;
	printf("\nEnter the number of colours available : ");count++;
	scanf("%d",&m);count++;
	printf("\nThe solutions to graph coloring problem are :\n");count++;
	mColoring(1);count++;
	printf("\nStep Count is %d\n",count);
    return 0;
}
void create_graph()
{
   	int i,max_edges,destin,origin;
   	printf("Enter the number of vertices : ");
   	scanf("%d",&n);count++;
    max_edges=n*(n-1)/2;count++;
    printf("\nEnter the edges :\n");
    for(i=1;i<=max_edges;i++)
    {
        count++;
        printf("Edge %d(-1,-1) to quit : ",i);count++;
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
            count+=2;
            break;
		}count++;
        if(origin>n || destin>n || origin<1 || destin<1)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            G[origin][destin]=1;count++;
            G[destin][origin]=1;count++;
        }count++;
    }count++;
}

