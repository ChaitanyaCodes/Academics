#include<stdio.h>
#define MAX 100
int count=0;
int arr[MAX];
int b[MAX];
void mergesort(int low,int high)
{
    int mid;
    if(low<high)
    {
        mid=(low+high)/2;count++;
        mergesort(low,mid);count++;
        mergesort(mid+1,high);count++;
        merge(low,mid,high);count++;
    }count++;
}
void merge(int low,int mid,int high)
{
    int h=low,i=low,j=mid+1,k;count+=3;
    while((h<=mid)&&(j<=high))
    {
        count+=2;
        if(arr[h]<=arr[j])
        {
            b[i]=arr[h];count++;
            h=h+1;count++;
        }
        else
        {
            b[i]=arr[j];count++;
            j=j+1;count++;
        }
        count++;
        i=i+1;count++;
    }count++;
    if(h>mid)
    {
        for(k=j;k<=high;k++)
        {
            count++;
            b[i]=arr[k];count++;
            i=i+1;count++;
        }count++;
    }
    else
    {
        for(k=h;k<=mid;k++)
        {
            count++;
            b[i]=arr[k];count++;
            i=i+1;count++;
        }count++;
    }
    count++;
    for(k=low;k<=high;k++)
    {
        count++;
        arr[k]=b[k];count++;
    }count++;
}

int main()
{
    int n,i;
    printf("Enter the size of the array : ");count++;
    scanf("%d",&n);count++;
    printf("Enter the elements : ");count++;
    count++;
    for(i=1;i<=n;i++)
    {
        count++;
        scanf("%d",&arr[i]);count++;
    }count++;

    mergesort(1,n);count++;

    printf("\nSorted array : ");count++;
    for(i=1;i<=n;i++)
    {
    	count++;
		printf("%d ",arr[i]);count++;
	}count++;

    printf("\n\nStep Count is %d\n",count);
    return 0;
}
