#include<stdio.h>
#define MAX 100
int count=0;
void maxmin(int arr[],int n, int *max,int *min);
int main()
{
    int arr[MAX],n,x,i,max,min;

    printf("Enter the size of the array : ");count++;
    scanf("%d",&n);count++;
    printf("Enter the elements : ");count++;
    for(i=1;i<=n;i++)
    {
    	count++;
    	scanf("%d",&arr[i]);
	}count++;
    maxmin(arr,n,&max,&min);count++;
    printf("\nMax : %d\nMin : %d\n",max,min);count++;
    printf("\nStep Count is %d\n",count);
    return 0;
}
void maxmin(int arr[],int n, int *max,int *min)
{
    *max=*min=arr[1];count++;
    int i;
    for(i=2;i<=n;i++)
    {
        count++;
		if(arr[i]>*max)
		{
			*max=arr[i];count++;
		}count++;
            
        if(arr[i]<*min)
        {
        	*min=arr[i];count++;
		}count++;
    }count++;
}
