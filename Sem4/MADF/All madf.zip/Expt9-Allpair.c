#include <stdio.h>
#include<stdlib.h>
#define MAX 100
#define infinity 999999
int count=0;
int cost[MAX][MAX],A[MAX][MAX];
int n;
void create_graph();
void allpaths();
void display();
int min(int a,int b);
int main()
{
	int s;
	create_graph();count++;
	allpaths(A);count++;
	printf("\nShortest path matrix is :\n");count++;
	display(A);count++;
	printf("\nStep Count is %d\n",count);
    return 0;
}
void allpaths()
{
	int i,j,k;
	for(i=1;i<=n;i++)
	{
		count++;
		for(j=0;j<=n;j++)
		{
			count++;
			A[i][j]=cost[i][j];count++;
		}count++;
	}count++;
	for(k=1;k<=n;k++)
	{
		count++;
		for(i=1;i<=n;i++)
		{
			count++;
			for(j=1;j<=n;j++)
			{
				count++;
				A[i][j]=min(A[i][j],A[i][k]+A[k][j]);count++;
			}count++;
		}count++;
	}count++;
}
int min(int a,int b)
{
	if(a>=infinity && b>=infinity)
	{
		count+=3;
		return(infinity);
	}
	else if(b<a)
	{
		count+=2;
		return(b);
	}
	else
	{
		count+=2;
		return(a);
	}
}
void display(int mat[MAX][MAX])
{
	int i,j;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(mat[i][j]!=infinity)
			printf("%5d ",mat[i][j]);
			else
			printf("  infy");
		}
		printf("\n");
	}
}
void create_graph()
{
   	int i,max_edges,destin,origin,ct,j;
   	printf("Enter the number of vertices : ");
   	scanf("%d",&n);count++;
    max_edges=n*(n-1);count++;
    printf("\nEnter the edges : ");

    for(i=1;i<=max_edges;i++)
    {
        count++;
        printf("\nEdge %d(-1,-1) to quit : ",i);
        scanf("%d %d",&origin,&destin);count++;
        if((origin==-1)&&(destin==-1))
        {
            count+=2;
            break;
		}count++;
        if(origin>n || destin>n || origin<1 || destin<1)
        {
            printf("\nInvalid edge!!!\n");
            i--;count++;
        }
        else
        {
            printf("Cost to go from %d to %d  : ",origin,destin);count++;
            scanf("%d",&ct);count++;
            cost[origin][destin]=ct;count++;
        }count++;
    }count++;
    printf("\nAdjacency Matrix :\n");count++;
	display(cost);count++;
    for(i=1;i<=n;i++)
	{
		count++;
		for(j=1;j<=n;j++)
		{
			count++;
			if (cost[i][j] == 0 && i!=j)
			{
				cost[i][j] = infinity;count++;
			}count+=2;
		}count++;
	}count++;
}

